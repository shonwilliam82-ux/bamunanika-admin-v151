# BAMUNANIKA ADMIN V15 — Android + Windows source

This package contains one shared dark glass-style dashboard design for Android and Windows.

## Features in this prototype
- Responsive dashboard and interactive Leaflet / OpenStreetMap map.
- First-run administrator password setup and local sign-in.
- Local phone registry with per-device registration codes and explicit consent confirmation.
- Local case register and status changes.
- GPS permission and location display for the device running the app.
- Camera and microphone permission tests for the device running the app.
- Android APK build and Windows NSIS installer + portable EXE build workflows.

## Build both from GitHub
1. Extract the contents of this ZIP into the root of `shonwilliam82-ux/bamunanika-admin` and upload/commit the files, keeping the `android/`, `windows/`, and `.github/` folders.
2. Open GitHub → Actions → **Build BAMUNANIKA ADMIN V15 Android and Windows** → **Run workflow**.
3. Download the two artifacts after both jobs succeed:
   - `BAMUNANIKA-ADMIN-V15-Android-APK`
   - `BAMUNANIKA-ADMIN-V15-Windows`

## Important limitations
This is a local application prototype, not a cloud-connected phone tracking system. Phone registration records are stored on each installation and are not synchronized between devices. Remote multi-phone location tracking requires a secure backend, authenticated device pairing, and an Android guest client that explicitly opts in and shares location. Camera/microphone permission tests only apply to the device running the app; remote access is not implemented. Location requires the user's permission and internet/GPS availability. A powered-off phone cannot transmit its location.

The Android bridge stores a salted password digest and local records in app-private preferences. For production deployment, use a vetted password KDF and a server-side identity/session system. Do not use this app to monitor anyone without their informed consent.
