const { app, BrowserWindow, ipcMain, session } = require('electron');
const path = require('path'); const fs = require('fs'); const crypto = require('crypto');
function file(){ return path.join(app.getPath('userData'),'bamunanika-data.json'); }
function read(){ try{return JSON.parse(fs.readFileSync(file(),'utf8'));}catch{return {admin:null,devices:[],cases:[]};} }
function write(d){fs.mkdirSync(path.dirname(file()),{recursive:true});fs.writeFileSync(file(),JSON.stringify(d,null,2),'utf8');}
function hash(p,s){return crypto.scryptSync(p,s,64).toString('hex');}
function equal(a,b){try{return crypto.timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex'));}catch{return false;}}
function create(){const w=new BrowserWindow({width:1440,height:900,minWidth:900,minHeight:620,backgroundColor:'#07090d',title:'BAMUNANIKA ADMIN V15',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}});w.loadFile(path.join(__dirname,'index.html'));}
app.whenReady().then(()=>{
 session.defaultSession.setPermissionRequestHandler((_wc,p,cb)=>cb(['media','geolocation'].includes(p)));
 session.defaultSession.setPermissionCheckHandler((_wc,p)=>['media','geolocation'].includes(p));
 ipcMain.handle('auth:status',()=>({configured:!!read().admin}));
 ipcMain.handle('auth:setup',(_e,p)=>{if(typeof p!=='string'||p.length<10)return {ok:false,error:'Use at least 10 characters.'};const d=read();if(d.admin)return {ok:false,error:'Administrator already configured.'};const salt=crypto.randomBytes(16).toString('hex');d.admin={salt,hash:hash(p,salt)};write(d);return {ok:true};});
 ipcMain.handle('auth:login',(_e,p)=>{const a=read().admin;if(!a)return {ok:false,error:'Create an administrator password first.'};return equal(hash(String(p),a.salt),a.hash)?{ok:true}:{ok:false,error:'Incorrect password.'};});
 ipcMain.handle('data:get',()=>{const d=read();return {devices:d.devices,cases:d.cases};});
 ipcMain.handle('device:add',(_e,v)=>{const d=read();const item={id:crypto.randomUUID(),name:String(v.name||'').slice(0,80),code:'BAM-'+crypto.randomBytes(3).toString('hex').toUpperCase(),phone:String(v.phone||'').slice(0,40),consent:!!v.consent,status:'PENDING',lastSeen:null};if(!item.name||!item.consent)return {ok:false,error:'Name and explicit owner consent are required.'};d.devices.unshift(item);write(d);return {ok:true,item};});
 ipcMain.handle('case:add',(_e,v)=>{const d=read();const item={id:crypto.randomUUID(),title:String(v.title||'').slice(0,120),details:String(v.details||'').slice(0,2000),priority:v.priority==='High'?'High':'Normal',status:'Open',createdAt:new Date().toISOString()};if(!item.title)return {ok:false,error:'Enter a case title.'};d.cases.unshift(item);write(d);return {ok:true,item};});
 ipcMain.handle('case:update',(_e,id,status)=>{const d=read();const c=d.cases.find(x=>x.id===id);if(!c)return {ok:false};c.status=['Open','In progress','Closed'].includes(status)?status:'Open';write(d);return {ok:true};});
 create();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)create();});
});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
