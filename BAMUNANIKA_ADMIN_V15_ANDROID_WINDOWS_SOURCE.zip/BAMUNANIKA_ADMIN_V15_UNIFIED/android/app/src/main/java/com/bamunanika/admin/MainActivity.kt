package com.bamunanika.admin

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("bamunanika_v15", MODE_PRIVATE) }
    private var pendingPermission: PermissionRequest? = null
    private val requestCode = 150

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setGeolocationEnabled(true)
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wanted = mutableListOf<String>()
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) wanted.add(Manifest.permission.CAMERA)
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) wanted.add(Manifest.permission.RECORD_AUDIO)
                    val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                    if (missing.isEmpty()) request.grant(request.resources) else {
                        pendingPermission = request
                        requestPermissions(missing.toTypedArray(), requestCode)
                    }
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                callback?.invoke(origin, granted, false)
                if (!granted) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode + 1)
            }
        }
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            val req = pendingPermission
            if (ok && req != null) req.grant(req.resources) else req?.deny()
            pendingPermission = null
        }
    }

    inner class Bridge {
        private fun devices() = JSONArray(prefs.getString("devices", "[]"))
        private fun cases() = JSONArray(prefs.getString("cases", "[]"))
        private fun result(ok: Boolean, error: String? = null) = JSONObject().put("ok", ok).apply { if (error != null) put("error", error) }.toString()
        @JavascriptInterface fun authStatus(): String = JSONObject().put("configured", prefs.contains("admin_hash")).toString()
        @JavascriptInterface fun setup(password: String): String {
            if (password.length < 10) return result(false, "Use at least 10 characters.")
            if (prefs.contains("admin_hash")) return result(false, "Administrator is already configured.")
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            prefs.edit().putString("admin_salt", salt.joinToString("") { "%02x".format(it) }).putString("admin_hash", digest(password, salt)).apply()
            return result(true)
        }
        @JavascriptInterface fun login(password: String): String {
            val saltHex = prefs.getString("admin_salt", null) ?: return result(false, "Set up the administrator password first.")
            val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            return if (digest(password, salt) == prefs.getString("admin_hash", "")) result(true) else result(false, "Incorrect administrator password.")
        }
        private fun digest(value: String, salt: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(salt + value.toByteArray()).joinToString("") { "%02x".format(it) }
        @JavascriptInterface fun getData(): String = JSONObject().put("devices", devices()).put("cases", cases()).toString()
        @JavascriptInterface fun addDevice(json: String): String {
            val v = JSONObject(json); if (v.optString("name").isBlank() || !v.optBoolean("consent")) return result(false, "Name and explicit tracking consent are required.")
            val item = JSONObject().put("id", java.util.UUID.randomUUID().toString()).put("name", v.optString("name").take(80)).put("phone", v.optString("phone").take(40)).put("code", "BAM-" + (1..6).map { "0123456789ABCDEF".random() }.joinToString("")).put("consent", true).put("status", "PENDING")
            val a = devices(); a.put(item); prefs.edit().putString("devices", a.toString()).apply(); return JSONObject().put("ok", true).put("item", item).toString()
        }
        @JavascriptInterface fun addCase(json: String): String {
            val v = JSONObject(json); if (v.optString("title").isBlank()) return result(false, "Enter a case title.")
            val item = JSONObject().put("id", java.util.UUID.randomUUID().toString()).put("title", v.optString("title").take(120)).put("details", v.optString("details").take(2000)).put("priority", v.optString("priority", "Normal")).put("status", "Open").put("createdAt", System.currentTimeMillis().toString())
            val a = cases(); a.put(item); prefs.edit().putString("cases", a.toString()).apply(); return JSONObject().put("ok", true).put("item", item).toString()
        }
        @JavascriptInterface fun updateCase(id: String, status: String): String {
            val a = cases(); for (i in 0 until a.length()) { val c = a.getJSONObject(i); if (c.optString("id") == id) c.put("status", if (status in listOf("Open", "In progress", "Closed")) status else "Open") }; prefs.edit().putString("cases", a.toString()).apply(); return result(true)
        }
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
