// Adapts the shared V15 dashboard to the Android native bridge.
window.bamunanika = {
  authStatus: async () => JSON.parse(AndroidBridge.authStatus()),
  setup: async p => JSON.parse(AndroidBridge.setup(p)),
  login: async p => JSON.parse(AndroidBridge.login(p)),
  getData: async () => JSON.parse(AndroidBridge.getData()),
  addDevice: async v => JSON.parse(AndroidBridge.addDevice(JSON.stringify(v))),
  addCase: async v => JSON.parse(AndroidBridge.addCase(JSON.stringify(v))),
  updateCase: async (id, status) => JSON.parse(AndroidBridge.updateCase(id, status))
};
