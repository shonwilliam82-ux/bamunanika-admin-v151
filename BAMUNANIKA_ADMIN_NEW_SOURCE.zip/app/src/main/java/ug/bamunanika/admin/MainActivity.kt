package ug.bamunanika.admin

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.content.Intent
import android.provider.Settings
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bamunanika_local", Context.MODE_PRIVATE) }
    private val bg = Color.rgb(10, 12, 18)
    private val panel = Color.rgb(24, 28, 39)
    private val accent = Color.rgb(91, 190, 255)
    private val permissionRequest = 41
    private var activeRole = ""
    private var activeCode = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.getBoolean("termsAccepted", false)) showTerms() else showHome()
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 26, 22, 24)
        setBackgroundColor(bg)
    }
    private fun label(s: String, size: Float = 16f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); setPadding(0, 8, 0, 8)
    }
    private fun field(hintText: String, secret: Boolean = false): EditText = EditText(this).apply {
        hint = hintText; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
        textSize = 16f; setSingleLine(true)
        if (secret) inputType = 129
        setPadding(14, 8, 14, 8)
        setBackgroundColor(panel)
    }
    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text = s; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(35, 91, 130))
        setOnClickListener { action() }
    }
    private fun screen(title: String): LinearLayout {
        val l = root()
        l.addView(label("BAMUNANIKA ADMIN", 13f))
        l.addView(label(title, 25f).apply { typeface = Typeface.DEFAULT_BOLD })
        setContentView(ScrollView(this).apply { addView(l) })
        return l
    }
    private fun showTerms() {
        val l = screen("Terms & Conditions")
        l.addView(label("Please read and accept before using the app."))
        l.addView(label("1. This app is for lawful, consent-based device management only.\\n\\n2. A registered device owner must knowingly agree to share location.\\n\\n3. Location is requested only after the user taps a location action and grants Android permission.\\n\\n4. Camera and microphone access must be started by the user and approved through Android permission prompts. This starter app does not secretly record or stream camera/audio.\\n\\n5. Location may be unavailable when the phone is offline, GPS is disabled, permission is denied, or the phone is powered off.\\n\\n6. This initial version stores registrations on this phone only. It does not sync data to an administrator over the internet.\\n\\n7. Do not register or monitor another person's device without their informed consent."))
        l.addView(button("ACCEPT TERMS & CONTINUE") { prefs.edit().putBoolean("termsAccepted", true).apply(); showHome() })
    }
    private fun showHome() {
        val l = screen("Welcome")
        l.addView(label("Consent-based device registration and location tools."))
        l.addView(button("ADMIN LOGIN / FIRST-TIME SETUP") { showAdminLogin() })
        l.addView(button("GUEST REGISTRATION") { showRegistration() })
        l.addView(button("GUEST DASHBOARD") { activeRole = "GUEST"; activeCode = ""; showDashboard() })
        l.addView(label("Privacy: location, camera and microphone are not accessed in the background by this starter app.", 13f))
    }
    private fun showAdminLogin() {
        val l = screen("Administrator")
        val user = field("Admin username")
        val pass = field("Admin password", true)
        l.addView(user); l.addView(pass)
        val exists = prefs.contains("adminPass")
        l.addView(label(if (exists) "Sign in with the administrator password created on this phone." else "First-time setup: choose a strong administrator password."))
        l.addView(button(if (exists) "SIGN IN" else "CREATE ADMIN ACCOUNT") {
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            if (u.isBlank() || p.length < 8) { toast("Enter a username and password of at least 8 characters."); return@button }
            if (!exists) {
                prefs.edit().putString("adminUser", u).putString("adminPass", p).apply()
                toast("Admin account created on this phone."); activeRole = "ADMIN"; showDashboard()
            } else if (u == prefs.getString("adminUser", "") && p == prefs.getString("adminPass", "")) {
                activeRole = "ADMIN"; showDashboard()
            } else toast("Incorrect administrator login.")
        })
        l.addView(button("BACK") { showHome() })
    }
    private fun showRegistration() {
        val l = screen("Guest registration")
        val name = field("Full name")
        val phone = field("Phone number")
        val model = field("Phone model (optional)")
        l.addView(name); l.addView(phone); l.addView(model)
        l.addView(label("By registering, you agree that location is shared only when you choose a location action and grant permission."))
        l.addView(button("REGISTER & GENERATE MY CODE") {
            val n = name.text.toString().trim()
            val p = phone.text.toString().trim()
            if (n.isBlank() || p.isBlank()) { toast("Enter your name and phone number."); return@button }
            val code = newCode()
            val obj = JSONObject().put("name", n).put("phone", p).put("model", model.text.toString()).put("code", code).put("created", System.currentTimeMillis())
            val arr = JSONArray(prefs.getString("guests", "[]"))
            arr.put(obj); prefs.edit().putString("guests", arr.toString()).apply()
            activeRole = "GUEST"; activeCode = code
            screen("Registration complete").apply {
                addView(label("Your unique registration code:", 16f))
                addView(label(code, 30f).apply { setTextColor(accent); typeface = Typeface.DEFAULT_BOLD })
                addView(label("Keep this code safe. In this starter version, it is saved only on this phone."))
                addView(button("OPEN GUEST DASHBOARD") { showDashboard() })
            }
        })
        l.addView(button("BACK") { showHome() })
    }
    private fun showDashboard() {
        val l = screen(if (activeRole == "ADMIN") "Administrator dashboard" else "Guest dashboard")
        l.addView(label(if (activeRole == "ADMIN") "ADMIN ACCESS • local device records" else "GUEST ACCESS • limited view"))
        if (activeCode.isNotBlank()) l.addView(label("Your code: $activeCode"))
        if (activeRole == "ADMIN") {
            val arr = JSONArray(prefs.getString("guests", "[]"))
            l.addView(label("Registered guests on this phone: ${arr.length()}"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                l.addView(label("${o.optString("name")} • ${o.optString("phone")}\\nCode: ${o.optString("code")}", 14f))
            }
        }
        l.addView(button("LOCATE THIS PHONE NOW") { locateNow() })
        l.addView(button("START LIVE LOCATION (WHILE APP IS OPEN)") { toast("Tap Locate Now to request a fresh location. Background tracking is not enabled.") })
        l.addView(button("CAMERA PERMISSION (USER INITIATED)") {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), permissionRequest)
            else toast("Camera permission is already granted. No recording is started.")
        })
        l.addView(button("MICROPHONE PERMISSION (USER INITIATED)") {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), permissionRequest)
            else toast("Microphone permission is already granted. No recording is started.")
        })
        l.addView(button("LOG OUT") { activeRole = ""; activeCode = ""; showHome() })
        l.addView(label("Important: records are local to this phone. This build does not provide remote admin tracking, cloud accounts, AI services, or tracking when the phone is off.", 13f))
    }
    private fun locateNow() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), permissionRequest)
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var best: Location? = null
            for (provider in providers) {
                val loc = lm.getLastKnownLocation(provider) ?: continue
                if (best == null || loc.accuracy < best!!.accuracy) best = loc
            }
            if (best != null) {
                screen("Your current location").apply {
                    addView(label("Latitude: ${best!!.latitude}"))
                    addView(label("Longitude: ${best!!.longitude}"))
                    addView(label("Accuracy: ${best!!.accuracy} metres"))
                    addView(button("BACK TO DASHBOARD") { showDashboard() })
                }
            } else {
                toast("No recent location fix. Turn on GPS, go outdoors, and try again.")
                startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
        } catch (_: SecurityException) { toast("Location permission is required.") }
    }
    private fun newCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        return "BAM-" + (1..10).map { chars[random.nextInt(chars.length)] }.joinToString("")
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
