# BAMUNANIKA ADMIN — starter Android project

## Build
Upload the contents of this folder to the root of your GitHub repository (keep `.github/workflows/build-apk.yml`), then open Actions and run **Build BAMUNANIKA ADMIN APK**. Download the `BAMUNANIKA-ADMIN-APK` artifact and extract `app-debug.apk`.

## Included
- First-launch Terms & Conditions acceptance
- Guest registration and cryptographically random unique registration code
- First-run administrator account setup and local login
- Separate admin and guest dashboard views
- Explicit, user-initiated Android location permission and last-known location display
- Explicit camera and microphone permission prompts (no hidden capture or recording)
- Dark Android interface

## Important limitations
This is a safe, local-only starter build. Guest records and admin credentials are stored on the same phone. There is no cloud database, remote administrator console, remote tracking, AI service, background location service, or Windows desktop app. The administrator can only see registrations created on that same installation. Do not use this as a production tracking or security system.

For a real multi-device service, add a secure backend (authentication, database, access rules, audit logs, consent revocation, retention/deletion controls) and a separately reviewed Android foreground location service with a persistent notification and clear opt-in. Camera/microphone capture must remain user initiated and visible.
