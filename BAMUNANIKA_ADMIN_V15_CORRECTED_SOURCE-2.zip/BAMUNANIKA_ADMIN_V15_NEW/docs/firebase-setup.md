# Firebase setup (required before cloud features work)

This repository contains Firebase client service code, Cloud Functions, Firestore rules and Storage rules. **No Firebase project, credentials, admin account or cloud database is included.** Never commit service-account JSON, private keys or production secrets.

## 1. Create your project
1. Open https://console.firebase.google.com/ and create a project named `bamunanika-admin` (or choose your own project ID).
2. Enable Authentication → Email/Password. Create the first administrator account.
3. Create a Cloud Firestore database in a region appropriate for your users. Enable Storage if you intend to upload evidence.
4. Install Node.js 20+, Firebase CLI and FlutterFire CLI on a computer.

## 2. Configure Flutter apps
From the repository root run:

```bash
flutter pub get
```

This source includes `lib/firebase_options.dart`, which reads the Firebase app identifiers from Dart defines. Obtain the real Android and Windows app identifiers from Firebase Console → Project settings → Your apps. Do not use sample values. Supply these at launch/build time:

```bash
--dart-define=BAMUNANIKA_FIREBASE=true \
--dart-define=FIREBASE_API_KEY=YOUR_PUBLIC_FIREBASE_API_KEY \
--dart-define=FIREBASE_APP_ID=YOUR_PLATFORM_APP_ID \
--dart-define=FIREBASE_MESSAGING_SENDER_ID=YOUR_SENDER_ID \
--dart-define=FIREBASE_PROJECT_ID=YOUR_PROJECT_ID \
--dart-define=FIREBASE_STORAGE_BUCKET=YOUR_BUCKET
```

Use the Android app ID for the APK and the Windows app ID for the Windows build. Firebase API keys/app IDs identify the client project; never place service-account private keys in the app. Keep `BAMUNANIKA_FIREBASE` false until real project values are provided.

## 3. Deploy backend rules and function

```bash
cd firebase/functions
npm install
npm run build
cd ../..
firebase login
firebase use YOUR_FIREBASE_PROJECT_ID
firebase deploy --only firestore:rules,firestore:indexes,storage,functions
```

Cloud Functions deployment may require the Blaze billing plan. Review Firebase pricing before enabling paid services.

## 4. Assign administrator role
The `admin` custom claim must be assigned from a trusted server or Firebase Admin SDK environment by the project owner. Never let a client app grant itself admin access. The included registration-code callable checks this claim. The starter package does not automatically promote any user.

## 5. Security and privacy checklist
- Publish a privacy notice explaining purpose, access, retention, sharing and deletion. Obtain explicit, revocable location consent.
- Keep location sharing off by default. Remove the live-location document when sharing is stopped.
- Do not collect location in the background unless a separate, explicit user-facing feature and required platform disclosures are implemented.
- Review Firestore rules with the Firebase Emulator Suite before production. Rules are a baseline, not a substitute for a security review.
- Add admin audit logs, account recovery, rate limiting, retention/deletion workflows and backups before production use.
- Use HTTPS/TLS (Firebase SDKs do this), least-privilege roles and a secure process for handling media.

## Current integration boundary
The Firebase service layer supports email/password auth, guest and case writes/streams, consent-based live-location writes/streams, and server-generated registration codes. Existing dashboard forms still use local prototype storage until explicitly wired to these service methods and an admin/guest account workflow. Do not represent local records as cloud-synchronised.
