# Backend integration and production checklist

This source is deliberately honest about its current capabilities: records are stored locally, there is no cloud sync, no multi-device location feed, and no background tracking service.

Before production, provision a backend (for example Firebase or Supabase) and implement:
- Server-side authentication and role-based access control.
- Guest profiles, cases, consent records, location sessions and expiring location points.
- Row-level security so each guest can manage only their own sharing and administrators can access only authorised records.
- Location ingestion only while a clear, active, revocable consent session exists.
- Visible Android foreground-service notification if background location is later added.
- TLS, audit logs, rate limits, retention/deletion controls and account recovery.
- Secrets in GitHub Actions Secrets or a backend secret manager, never in Dart source.

Do not use this application for covert tracking. Every tracked device must be registered, informed and able to stop sharing.
