# BAMUNANIKA ADMIN V15 — Android + Windows shared source

Flutter project scaffold with a responsive black/glass dashboard, first-launch terms gate, local admin passcode setup, guest registration and unique codes, local case management, interactive OpenStreetMap, foreground one-time GPS location, visible session sharing toggle, and camera/microphone permission workflows.

## Build
The GitHub Actions workflow generates Android and Windows platform folders and builds both targets. Upload the contents of this folder to the root of `shonwilliam82-ux/bamunanika-admin` and run Actions.

- Android: APK artifact.
- Windows: portable release bundle ZIP (not an installer).

## Important limitations
This is a starter implementation, not a finished production platform. Guest and case data are device-local. Cloud database, remote authentication, multi-phone sync, background location tracking, installer packaging, release signing and production security are not configured. The admin passcode is a local prototype gate. Review and test all platform permissions before distribution. See `docs/BACKEND_INTEGRATION.md`.


## Expanded Firebase-ready project
This version includes Firebase Auth/Firestore/Storage/Functions dependencies, a reusable Firebase service layer, guest/case/location models, Firestore and Storage security-rule baselines, indexes, a server-side unique registration-code callable, and setup/architecture documentation. See `docs/firebase-setup.md`.

**Not yet live:** actual Firebase project credentials, generated `firebase_options.dart`, admin custom-claim provisioning, UI wiring for cloud operations, multi-device guest app, background tracking, production security review, and installer packaging. The local dashboard remains local-first until these steps are completed.

## Windows installer target
The Windows workflow now includes an Inno Setup script at `installer/BamunanikaAdmin.iss` and attempts to publish both a portable ZIP and setup EXE. The installer is produced only if the Windows workflow completes successfully.
