#define AppName "BAMUNANIKA ADMIN V15"
#define AppVersion "15.0.0"
#define AppPublisher "BAMUNANIKA ADMIN"
#define AppExeName "bamunanika_admin.exe"
[Setup]
AppId={{7B83D119-2A90-4E3D-A08B-2E2E8A15D015}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\BAMUNANIKA ADMIN V15
DefaultGroupName={#AppName}
OutputDir=output
OutputBaseFilename=BAMUNANIKA-ADMIN-V15-SETUP
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
[Files]
Source: "..\build\windows\x64\runner\Release\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"
[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; Flags: postinstall nowait skipifsilent
