class Guest {
  const Guest({required this.id, required this.name, required this.phone,
    required this.registrationCode, this.status = 'active'});
  final String id, name, phone, registrationCode, status;
  Map<String, Object?> toMap() => {'id': id, 'name': name, 'phone': phone,
    'registrationCode': registrationCode, 'status': status};
  factory Guest.fromMap(String id, Map<String, dynamic> map) => Guest(id: id,
    name: map['name'] as String? ?? '', phone: map['phone'] as String? ?? '',
    registrationCode: map['registrationCode'] as String? ?? '',
    status: map['status'] as String? ?? 'active');
}
