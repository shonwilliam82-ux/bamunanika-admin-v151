import 'dart:convert';
import 'package:flutter/material.dart';
import 'services/firebase_service.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

const bg=Color(0xFF080B10), panel=Color(0xDD151C27), accent=Color(0xFF50E3C2), muted=Color(0xFF9BA8B8);
Future<void> main() async { WidgetsFlutterBinding.ensureInitialized(); await FirebaseService.initializeIfConfigured(); runApp(const BamunanikaApp()); }
class BamunanikaApp extends StatelessWidget { const BamunanikaApp({super.key}); @override Widget build(BuildContext c)=>MaterialApp(title:'BAMUNANIKA ADMIN V15',debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true).copyWith(scaffoldBackgroundColor:bg,colorScheme:const ColorScheme.dark(primary:accent,surface:panel)),home:const Gate()); }
class DB {
 static Future<SharedPreferences> get p=>SharedPreferences.getInstance();
 static Future<bool> terms() async=>(await p).getBool('terms')??false;
 static Future<void> accept() async=>(await p).setBool('terms',true);
 static Future<String?> pin() async=>(await p).getString('admin_pin');
 static Future<void> setPin(String v) async=>(await p).setString('admin_pin',v);
 static Future<List<Map<String,dynamic>>> list(String k) async { final s=(await p).getString(k); if(s==null)return []; try{return (jsonDecode(s) as List).cast<Map<String,dynamic>>();}catch(_){return [];} }
 static Future<void> save(String k,List<Map<String,dynamic>> v) async=>(await p).setString(k,jsonEncode(v));
}
class Gate extends StatefulWidget {const Gate({super.key});@override State<Gate> createState()=>_GateState();}
class _GateState extends State<Gate>{bool? ok;@override void initState(){super.initState();DB.terms().then((v){if(mounted)setState(()=>ok=v);});}@override Widget build(BuildContext c){if(ok==null)return const Scaffold(body:Center(child:CircularProgressIndicator()));return ok!?const Login():Terms(onYes:()async{await DB.accept();if(mounted)setState(()=>ok=true);});}}
class Terms extends StatelessWidget {
  final VoidCallback onYes;
  const Terms({super.key, required this.onYes});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Card(
              color: panel,
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Brand(),
                    const SizedBox(height: 22),
                    const Text('TERMS & CONSENT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    const Text(
                      '• Location is accessed only when a user explicitly requests a fix or enables visible sharing.\n'
                      '• Camera and microphone permissions are requested only when their features are started.\n'
                      '• Do not use this app for covert tracking or unlawful surveillance.\n'
                      '• Users must be informed about collection, use, retention and deletion of their information.\n'
                      '• Records in this starter version remain on this device; no cloud sync is active.',
                    ),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: onYes, child: const Text('I HAVE READ AND ACCEPT')),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final ctrl = TextEditingController();
  bool setup = false;
  String err = '';

  @override
  void initState() {
    super.initState();
    DB.pin().then((value) {
      if (mounted) setState(() => setup = value == null);
    });
  }

  Future<void> go() async {
    final value = ctrl.text.trim();
    if (value.length < 6) {
      setState(() => err = 'Passcode must contain at least 6 characters.');
      return;
    }
    if (setup) await DB.setPin(value);
    if (value == await DB.pin()) {
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
      }
    } else {
      setState(() => err = 'Incorrect passcode.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 430),
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Card(
              color: panel,
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Brand(),
                    const SizedBox(height: 24),
                    Text(setup ? 'CREATE ADMIN PASSCODE' : 'ADMIN SIGN IN'),
                    const SizedBox(height: 12),
                    TextField(
                      controller: ctrl,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Passcode (minimum 6 characters)'),
                    ),
                    if (err.isNotEmpty) Text(err, style: const TextStyle(color: Colors.redAccent)),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(onPressed: go, child: const Text('CONTINUE')),
                    ),
                    const Text(
                      'First launch creates a device-local passcode. Production authentication requires a secure backend.',
                      style: TextStyle(color: muted, fontSize: 11),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }
}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{int tab=0;List<Map<String,dynamic>> guests=[],cases=[];Position? pos;bool sharing=false,busy=false;String status='GPS sharing is off';final picker=ImagePicker();final recorder=AudioRecorder();@override void initState(){super.initState();load();}Future<void> load()async{guests=await DB.list('guests');cases=await DB.list('cases');if(mounted)setState((){});}void msg(String s){if(!mounted)return;setState(()=>status=s);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
Future<void> locate()async{setState(()=>busy=true);try{if(!await Geolocator.isLocationServiceEnabled())throw Exception('Turn on GPS.');var p=await Geolocator.checkPermission();if(p==LocationPermission.denied)p=await Geolocator.requestPermission();if(p==LocationPermission.denied||p==LocationPermission.deniedForever)throw Exception('Location permission not granted.');pos=await Geolocator.getCurrentPosition();msg('Location fix: ${pos!.latitude.toStringAsFixed(5)}, ${pos!.longitude.toStringAsFixed(5)}');}catch(e){msg(e.toString().replaceFirst('Exception: ',''));}if(mounted)setState(()=>busy=false);}
Future<void> share(bool v)async{if(v){final p=await Permission.locationWhenInUse.request();if(!p.isGranted){msg('Location permission denied.');return;}await locate();}setState(()=>sharing=v);msg(v?'Visible location sharing enabled for this session.':'Location sharing stopped.');}
Future<void> addGuest(String n,String phone)async{final code='BAM-${const Uuid().v4().substring(0,8).toUpperCase()}';guests.insert(0,{'id':const Uuid().v4(),'name':n,'phone':phone,'code':code,'created':DateTime.now().toIso8601String()});await DB.save('guests',guests);setState((){});msg('Guest registered. Code: $code');}
Future<void> addCase(String title,String details,String code)async{cases.insert(0,{'id':const Uuid().v4(),'title':title,'details':details,'guestCode':code,'status':'Open','created':DateTime.now().toIso8601String()});await DB.save('cases',cases);setState((){});msg('Case saved locally.');}
Future<void> camera()async{if(!(await Permission.camera.request()).isGranted){msg('Camera permission denied.');return;}try{final x=await picker.pickImage(source:ImageSource.camera);if(x!=null)msg('Photo captured: ${x.name}');}catch(e){msg('Camera unavailable: $e');}}
Future<void> mic()async{if(!(await Permission.microphone.request()).isGranted){msg('Microphone permission denied.');return;}try{if(await recorder.hasPermission()){await recorder.start(const RecordConfig(),path:'${DateTime.now().millisecondsSinceEpoch}.m4a');msg('Recording started. Use STOP to finish.');}}catch(e){msg('Microphone unavailable: $e');}}
Future<void> stopMic()async{try{final p=await recorder.stop();msg(p==null?'Recording stopped.':'Saved recording: $p');}catch(_){msg('No active recording.');}}
@override Widget build(BuildContext c){final wide=MediaQuery.sizeOf(c).width>850;final pages=[overview(),guestPage(),casePage(),mapPage(),toolsPage()];return Scaffold(appBar:AppBar(title:const Text('BAMUNANIKA ADMIN  /  V15'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:Row(children:[if(wide)NavigationRail(backgroundColor:const Color(0xFF0D131D),selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),labelType:NavigationRailLabelType.all,destinations:const [NavigationRailDestination(icon:Icon(Icons.dashboard),label:Text('Overview')),NavigationRailDestination(icon:Icon(Icons.people),label:Text('Guests')),NavigationRailDestination(icon:Icon(Icons.folder),label:Text('Cases')),NavigationRailDestination(icon:Icon(Icons.map),label:Text('Map')),NavigationRailDestination(icon:Icon(Icons.settings),label:Text('Tools'))]),Expanded(child:pages[tab])]),bottomNavigationBar:wide?null:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.dashboard),label:'Home'),NavigationDestination(icon:Icon(Icons.people),label:'Guests'),NavigationDestination(icon:Icon(Icons.folder),label:'Cases'),NavigationDestination(icon:Icon(Icons.map),label:'Map'),NavigationDestination(icon:Icon(Icons.settings),label:'Tools') ]));}
Widget heading(String a,String b)=>Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold,letterSpacing:1)),Text(b,style:const TextStyle(color:muted))]));
Widget card(Widget child)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white12)),child:child);
Widget overview()=>ListView(padding:const EdgeInsets.all(18),children:[heading('OPERATIONS OVERVIEW','Registration • Cases • Consent-based location'),Wrap(spacing:10,runSpacing:10,children:[card(Text('GUESTS  ${guests.length}')),card(Text('CASES  ${cases.length}')),card(Text('GPS  ${sharing?'SHARING':'OFF'}'))]),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('LOCATION CONTROL',style:TextStyle(fontWeight:FontWeight.bold)),Text(status,style:const TextStyle(color:muted)),if(pos!=null)Text('${pos!.latitude}, ${pos!.longitude}'),SwitchListTile(contentPadding:EdgeInsets.zero,value:sharing,onChanged:share,title:const Text('Share this device location'),subtitle:const Text('Visible, session-based control')),FilledButton.icon(onPressed:busy?null:locate,icon:const Icon(Icons.my_location),label:Text(busy?'LOCATING':'LOCATE NOW'))])),Wrap(spacing:8,children:[OutlinedButton(onPressed:()=>setState(()=>tab=1),child:const Text('Register guest')),OutlinedButton(onPressed:()=>setState(()=>tab=2),child:const Text('New case')),OutlinedButton(onPressed:()=>setState(()=>tab=3),child:const Text('Open map'))])]);
Widget guestPage()=>ListView(padding:const EdgeInsets.all(18),children:[heading('GUEST REGISTRATION','Create a guest profile and unique code.'),FilledButton.icon(onPressed:guestDialog,icon:const Icon(Icons.person_add),label:const Text('REGISTER GUEST')),const SizedBox(height:12),if(guests.isEmpty)card(const Text('No guests registered on this device.',style:TextStyle(color:muted))) else ...guests.map((g)=>card(ListTile(leading:const Icon(Icons.person,color:accent),title:Text('${g['name']}'),subtitle:Text('${g['phone']}\n${g['code']}'))))]);
Widget casePage()=>ListView(padding:const EdgeInsets.all(18),children:[heading('CASE MANAGEMENT','Create cases linked to guest registration codes.'),FilledButton.icon(onPressed:caseDialog,icon:const Icon(Icons.add),label:const Text('CREATE CASE')),const SizedBox(height:12),if(cases.isEmpty)card(const Text('No cases recorded.',style:TextStyle(color:muted))) else ...cases.map((x)=>card(ListTile(leading:const Icon(Icons.assignment,color:accent),title:Text('${x['title']}'),subtitle:Text('${x['details']}\nGuest: ${x['guestCode']} • ${x['status']}'))))]);
Widget mapPage()=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[const Expanded(child:Text('INTERACTIVE MAP',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18))),FilledButton(onPressed:locate,child:const Text('LOCATE'))])),Expanded(child:FlutterMap(options:MapOptions(initialCenter:pos==null?const LatLng(0.3476,32.5825):LatLng(pos!.latitude,pos!.longitude),initialZoom:pos==null?11:15),children:[TileLayer(urlTemplate:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',userAgentPackageName:'com.bamunanika.admin'),if(pos!=null)MarkerLayer(markers:[Marker(point:LatLng(pos!.latitude,pos!.longitude),width:45,height:45,child:const Icon(Icons.location_pin,color:accent,size:42))]),const RichAttributionWidget(attributions:[TextSourceAttribution('© OpenStreetMap contributors')])])),const Padding(padding:EdgeInsets.all(8),child:Text('Only this device location is displayed. Remote-device tracking requires a configured backend and each user’s consent.',style:TextStyle(color:muted,fontSize:11)))]);
Widget toolsPage()=>ListView(padding:const EdgeInsets.all(18),children:[heading('DEVICE TOOLS','Permissions requested only when a feature is used.'),card(Column(children:[ListTile(leading:const Icon(Icons.camera_alt,color:accent),title:const Text('Camera'),trailing:FilledButton(onPressed:camera,child:const Text('OPEN'))),ListTile(leading:const Icon(Icons.mic,color:accent),title:const Text('Microphone'),trailing:FilledButton(onPressed:mic,child:const Text('START'))),ListTile(title:const Text('Stop recording'),trailing:OutlinedButton(onPressed:stopMic,child:const Text('STOP')))])),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('SERVICE STATUS',style:TextStyle(fontWeight:FontWeight.bold)),Text('Cloud sync: ${FirebaseService.isReady ? 'INITIALIZED' : 'NOT CONFIGURED'}',style:const TextStyle(color:Colors.orangeAccent)),const Text('Cloud operations still require sign-in and connection of the dashboard forms. Local records are not automatically migrated.',style:TextStyle(color:muted)),const SizedBox(height:8),const Text('Production requires server authentication, role-based access, encrypted transport, audit logs and retention controls.',style:TextStyle(color:muted))]))]);
Future<void> guestDialog()async{final n=TextEditingController(),p=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Register guest'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Full name')),TextField(controller:p,decoration:const InputDecoration(labelText:'Phone number'),keyboardType:TextInputType.phone)]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('CANCEL')),FilledButton(onPressed:(){if(n.text.trim().isNotEmpty&&p.text.trim().isNotEmpty){addGuest(n.text.trim(),p.text.trim());Navigator.pop(context);}},child:const Text('SAVE'))]));}
Future<void> caseDialog()async{final t=TextEditingController(),d=TextEditingController(),g=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Create case'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:t,decoration:const InputDecoration(labelText:'Case title')),TextField(controller:d,decoration:const InputDecoration(labelText:'Details'),maxLines:3),TextField(controller:g,decoration:const InputDecoration(labelText:'Guest code'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('CANCEL')),FilledButton(onPressed:(){if(t.text.trim().isNotEmpty){addCase(t.text.trim(),d.text.trim(),g.text.trim());Navigator.pop(context);}},child:const Text('SAVE'))]));}
@override void dispose(){recorder.dispose();super.dispose();}}
class Brand extends StatelessWidget{const Brand({super.key});@override Widget build(BuildContext c)=>const Row(children:[Icon(Icons.shield_moon,color:accent,size:34),SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('BAMUNANIKA ADMIN',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.2)),Text('V15 • OPERATIONS CONSOLE',style:TextStyle(color:muted,fontSize:10))]))]);}
