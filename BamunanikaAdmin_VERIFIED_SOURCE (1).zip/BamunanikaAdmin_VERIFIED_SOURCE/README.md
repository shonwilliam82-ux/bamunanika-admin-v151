# BAMUNANIKA ADMIN (Android project)

This repository contains the Android WebView wrapper and the V15.1 admin dashboard.

## Build an APK with GitHub Actions (phone-friendly)

1. Upload **the contents of this folder** to the root of a GitHub repository. The `.github` folder must be at the repository root (not nested inside another folder).
2. In GitHub, open the repository's **Actions** tab.
3. Select **Build BAMUNANIKA ADMIN APK**.
4. Tap **Run workflow** and confirm.
5. Wait for the run to finish successfully. Open the completed run and download the `bamunanika-admin-debug-apk` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone. Android may ask you to allow installs from that browser/file manager.

The workflow builds a **debug APK**, not a Play Store release. The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, and Java 17.

## Important behavior and limitations

- Location requires the device user's knowledge, permission, and enabled location services.
- Tracking runs while the app/WebView is active; this project does **not** implement a persistent Android background-location service and must not be treated as guaranteed background tracking.
- Dashboard records and the admin password verifier are stored locally in WebView storage on this device. There is no server, cloud database, remote account, or multi-device synchronization.
- The local admin screen is a basic device-level gate, not server-side authentication. Anyone with sufficient access to the app/device data may be able to bypass it.
- The map uses Leaflet from an HTTPS CDN, so an internet connection is needed for map assets/tiles.
