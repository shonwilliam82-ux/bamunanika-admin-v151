AI Android project - access roles update

This update adds:
- Master administrator sign-in using the existing local password setup.
- A guest entry option.
- A guest-only feature overview (view-only; no private case/location data or admin tools displayed).
- Logout back to the access screen.

IMPORTANT: This is a client-side prototype. The existing administrator password verifier is stored locally. The role UI is not a substitute for server-side authentication/authorization. Before deploying a real multi-user tracking service, add a secure backend that checks the master_admin role on every protected endpoint and enforces device-owner consent. See ACCESS_CONTROL_SPEC.md.

Manual test:
1. Install/build the app.
2. Choose CONTINUE AS GUEST. Confirm the feature overview appears and admin tools do not.
3. Log out.
4. Sign in as the master admin. Confirm the full dashboard appears.
5. Log out again.
