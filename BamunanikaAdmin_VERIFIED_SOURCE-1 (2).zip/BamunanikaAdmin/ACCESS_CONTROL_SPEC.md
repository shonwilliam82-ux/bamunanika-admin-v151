# AI access-control implementation

## Roles in this build

- **Master administrator:** uses the existing administrator password screen and receives the full existing app dashboard after sign-in.
- **Guest:** can enter without an administrator password and sees a feature-only dashboard. Tracking, case records, AI administration, device management, and settings are not displayed in guest mode.
- **Logout:** returns either role to the access screen.

## Important security boundary

This project currently stores the administrator password verifier locally in the Android WebView/browser storage. The guest/admin distinction in this build is a client-side interface gate, not production-grade server authorization. A technically capable user with device/debug/source access could bypass client-side UI restrictions. Do not use this build as a multi-user production tracking service until a backend is deployed that authenticates accounts and enforces role checks on every protected API/database operation.

## Production requirements before public release

1. Create a server-side master administrator account; do not hard-code credentials in the app.
2. Issue short-lived authenticated sessions and support logout/revocation.
3. Enforce `master_admin` and `guest` roles on the server, not only in the UI.
4. Require explicit device-owner consent before device enrollment and location sharing; support revocation.
5. Only return a device's location to an authenticated master administrator, with audit logs and rate limits.
6. Keep AI provider secrets on the server. The AI assistant should receive only the user's typed prompt in advisory mode unless separately authorized.
7. Use HTTPS, secure storage, database access rules, and account recovery controls.

## Manual test

- Open the app and choose **CONTINUE AS GUEST**: only the feature overview should appear.
- Tap **LOG OUT**: the access screen should return.
- Set up/sign in as `admin`: the full existing dashboard should appear.
- Tap **LOG OUT**: the access screen should return again.
